Thanks for your support ;)

Let us know anytime on info@deeezy.com or info@dealjumbo.com


Instructions for SVG color fonts:

- Color SVG opentype fonts are pretty new technology � they currently show up in Photoshop CC 2017+, Illustrator CC 2018 and some Mac apps. Learn more about color font support on third-party apps here: https://www.colorfonts.wtf/

- Please setup fonts to smooth style if you see crispy borders on your color fonts in Adobe Photshop!

- be sure you'll create type area on whole window...if you can see some part of letters are outside this area you need to space it into area to see letters propertly!

- If you need realistic brush effect on SVG font please select : 1. dark font on light background - Multiply layer effect & 2. light font on dark background - Screen layer effect on font layer